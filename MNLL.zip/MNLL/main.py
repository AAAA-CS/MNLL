import argparse
from utils import load_config,  set_seed, \
     record, aa_and_each_accuracy, Draw_Classification_Map

import algorithms
import numpy as np
import nni
import collections
from sklearn import metrics
from dataset import data_processing
parser = argparse.ArgumentParser()
parser.add_argument('--config', '-c', type=str, default='./configs/mnll.py',
                    help='The path of config file.')
args = parser.parse_args()


def main():
    tuner_params = nni.get_next_parameter()
    config = load_config(args.config, _print=True)
    config.update(tuner_params)

    # load data
    all_iter, BAND, BAND1, CLASSES_NUM, data_shape = data_processing(Dataset=config['dataset'], batch_size=config['batch_size'],
                                                              PATCH_LENGTH=config['patch_length'],flag='testAll')

    # seeds = [0, 1, 2,3,4,5,6,7,8,9]
    seeds = [0]
    overall_acc, aver_acc, KAPPA = [], [], []
    ELEMENT_ACC = np.zeros((len(seeds), CLASSES_NUM))
    count = 0
    for seed in seeds:

        set_seed(seed)
        # load dataset

        train_loader, test_loader,_ = data_processing(Dataset=config['dataset'], batch_size=config['batch_size'],
                                                                   PATCH_LENGTH=config['patch_length'],
                                                                   Train_size=config['train_size'],
                                                                   flag='train', noise_type=config['noise_type'],
                                                                   noise_ratio=config['percent'],
                                                                    noise_ratio2=config['percent2'])

        model = algorithms.__dict__[config['algorithm']](config, input_channel=BAND, num_classes=CLASSES_NUM)

        # train and test
        acc_all_list,train_acc_list = [],[]
        for epoch in range(1, config['epochs']):
            # train
            if epoch <= config['warmup']:
                Tr_acc = model.warmuptrain(train_loader, epoch)
                train_acc_list.extend([Tr_acc])
            else:
                Tr_acc = model.train(train_loader, epoch)

            train_acc_list.extend([Tr_acc])
        # test, just depend on the model of the last epoch
        acc1, pre1, gt_test = model.evaluate(test_loader)
        collections.Counter(pre1)
        OA = metrics.accuracy_score(pre1, gt_test)
        confusion_matrix = metrics.confusion_matrix(pre1, gt_test)
        Each_acc, AA = aa_and_each_accuracy(confusion_matrix)
        Kappa = metrics.cohen_kappa_score(pre1, gt_test)
        print('OA, AA, Kappa:', OA, AA, Kappa)
        print(Each_acc)
        KAPPA.append(Kappa)
        overall_acc.append(OA)
        aver_acc.append(AA)
        ELEMENT_ACC[count, :] = Each_acc
        count += 1

        nni.report_final_result(OA)
        print('  ********************************************  ')

    # Draw the classification map
    _, pre1, _ = model.evaluate(all_iter)
    pre1 = np.array(pre1).reshape((data_shape[0], data_shape[1]))
    Draw_Classification_Map(pre1 + 1,
                            'log/' + config['dataset'] + '_' +
                            config['noise_type'] + str(config['percent']))


    # Save the average accuracy to .txt
    if config['save_result']:
        record.record_output(overall_acc, aver_acc, KAPPA, ELEMENT_ACC,
                             'log/' + config['dataset'] + '_' +
                             config['noise_type'] + str(config['percent']) + '.txt')



if __name__ == '__main__':
    main()
