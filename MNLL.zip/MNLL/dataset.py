from sklearn import preprocessing
import numpy as np
from operator import truediv
import scipy.io as sio
import torch
import torch.utils.data as Data
import torch.nn as nn
import random
from torchvision.transforms import transforms

def data_processing(Dataset='Houston2013', batch_size=64, PATCH_LENGTH=11, flag='Train', Train_size=76, noise_type='sym',
                    noise_ratio=24,noise_ratio2=24):

    print('The name of Dataset:', Dataset)
    data_hsi, data_dmi, gt, TOTAL_SIZE = load_dataset(Dataset)

    print(data_hsi.shape, data_dmi.shape)
    image_x, image_y, BAND_HSI = data_hsi.shape
    _, _, BAND_DSM = data_dmi.shape
    data_hsi = data_hsi.reshape(np.prod(data_hsi.shape[:2]), np.prod(data_hsi.shape[2:]))  # h*w row, d column
    data_dmi = data_dmi.reshape(np.prod(data_dmi.shape[:2]), np.prod(data_dmi.shape[2:]))  # h*w row, d column
    gt_h = gt.reshape(np.prod(gt.shape[:2]), )
    CLASSES_NUM = max(gt_h)
    print('The class numbers of the HSI data is:', CLASSES_NUM)

    INPUT_DIMENSION_HSI = BAND_HSI
    INPUT_DIMENSION_DSM = BAND_DSM
    data_hsi = preprocessing.scale(data_hsi)
    data_dmi = preprocessing.scale(data_dmi)

    data_hsi = data_hsi.reshape(image_x, image_y, INPUT_DIMENSION_HSI)
    data_dmi = data_dmi.reshape(image_x, image_y, INPUT_DIMENSION_DSM)
    padded_data_hsi = np.lib.pad(data_hsi,
                                 ((PATCH_LENGTH // 2, PATCH_LENGTH // 2), (PATCH_LENGTH // 2, PATCH_LENGTH // 2), (0, 0)),
                                 'constant', constant_values=0)  # padding
    padded_data_dmi = np.lib.pad(data_dmi,
                                 ((PATCH_LENGTH // 2, PATCH_LENGTH // 2), (PATCH_LENGTH // 2, PATCH_LENGTH // 2), (0, 0)),
                                 'constant', constant_values=0)  # padding

    if flag == 'testAll':
        true_point = get_all_index(gt, CLASSES_NUM)
        train_iter = generate_all(true_point, PATCH_LENGTH, padded_data_hsi, padded_data_dmi, INPUT_DIMENSION_HSI, INPUT_DIMENSION_DSM)
        return train_iter, INPUT_DIMENSION_HSI, INPUT_DIMENSION_DSM, CLASSES_NUM, data_hsi.shape
    if flag == 'train':
        train_indices, train_gt, test_indices, test_gt = sampling(Train_size, gt, CLASSES_NUM)
        train_iter, test_iter = generate_iter(train_gt, train_indices, test_gt, test_indices,
                                                          train_indices.shape[0],
                                                          PATCH_LENGTH, padded_data_hsi, padded_data_dmi, INPUT_DIMENSION_HSI, INPUT_DIMENSION_DSM, batch_size,
                                                          noise_type, noise_ratio,noise_ratio2)

        return train_iter, test_iter, train_indices

class RandomSpectralShift(nn.Module):
    def __init__(self, shift_spectral_num=10):
        super(RandomSpectralShift, self).__init__()
        self.shift_spectral_num = shift_spectral_num
        # self.channels_range = list(range(spectral_num))  # feature_channels

    def forward(self, x):
        # print(x.shape)
        x = self.shift(x, shift_spectral_num=self.shift_spectral_num, channels_range=list(range(x.shape[2])))
        return x

    @staticmethod
    def shift(x, shift_spectral_num, channels_range):
        # print(x.shape)
        # x = rearrange(x, 'C S H W -> C H W S')
        # print(x.shape)
        all = random.sample(channels_range, shift_spectral_num)
        forward = sorted(all[: shift_spectral_num // 2])
        backward = sorted(all[shift_spectral_num // 2:])
        fixed = list(set(channels_range) - set(all))

        out = np.zeros_like(x)
        # print(out.shape)
        out[:, : -1, forward] = x[:, 1:, forward]  # shift left
        out[:, 1:, backward] = x[:, :-1, backward]  # shift right
        out[:-1, :, forward] = x[1:, :, forward]  # shift left
        out[1:, :, backward] = x[:-1, :, backward]  # shift right
        out[:, :, fixed] = x[:, :, fixed]  # not shift

        # out = rearrange(out, 'H W S -> S H W')
        return out


class RandomSpatialRotate(nn.Module):
    def __init__(self, p=0.05):
        super(RandomSpatialRotate, self).__init__()
        self.p = p

    def forward(self, x):
        if round(np.random.uniform(0, 1), 1) <= self.p:
            x = self.rotate(x)
        return x

    def rotate(self, x):
        idx = random.randint(0, 3)
        out = np.rot90(x, k=idx, axes=(0, 1)).copy()
        return out

class RandomGaussianNoise(nn.Module):
    def __init__(self, mean=0.0, std=0.1):
        super(RandomGaussianNoise, self).__init__()
        self.mean = mean
        self.std = std

    def forward(self, x):
        noise = np.random.normal(self.mean, self.std, x.shape)
        return (x + noise).astype(x.dtype)


class HSIDA(Data.Dataset):
    def __init__(
            self,
            images,
            labels,
            labels_gt,
            mode,
    ) -> None:

        self.transform_weak = transforms.Compose([
            RandomSpatialRotate(),
        ])
        self.transform_hsi_strong = transforms.Compose([
            RandomSpectralShift(),
            RandomSpatialRotate(),
        ])
        self.transform_dmi_strong = transforms.Compose([
            RandomGaussianNoise(),
            RandomSpatialRotate(),
        ])


        self.mode = mode
        self.images_hsi, self.images_dmi = images
        self.label_hsi, self.label_dmi = labels
        self.labels_gt = labels_gt

    def __getitem__(self, index):
        image_hsi, image_dmi, label_hsi, label_dmi = self.images_hsi[index], self.images_dmi[index], self.label_hsi[index], self.label_dmi[index]
        if self.mode == 'train':
            raw_hsi = torch.from_numpy(image_hsi.transpose(2, 0, 1)).type(torch.FloatTensor)
            raw_dmi = torch.from_numpy(image_dmi.transpose(2, 0, 1)).type(torch.FloatTensor)
            img1_hsi = torch.from_numpy(self.transform_weak(image_hsi).transpose(2,0,1)).type(torch.FloatTensor)
            img2_hsi = torch.from_numpy(self.transform_hsi_strong(image_hsi).transpose(2,0,1)).type(torch.FloatTensor)
            img1_dmi = torch.from_numpy(self.transform_weak(image_dmi).transpose(2,0,1)).type(torch.FloatTensor)
            img2_dmi = torch.from_numpy(self.transform_dmi_strong(image_dmi).transpose(2,0,1)).type(torch.FloatTensor)
            return raw_hsi, raw_dmi, label_hsi, label_dmi, index,img1_hsi,img2_hsi,img1_dmi,img2_dmi
        elif self.mode == 'test':
            img_hsi = torch.from_numpy(image_hsi.transpose(2, 0, 1)).type(torch.FloatTensor)
            img_dmi = torch.from_numpy(image_dmi.transpose(2, 0, 1)).type(torch.FloatTensor)
            return img_hsi, img_dmi, label_hsi, label_dmi, index

    def __len__(self):
        return len(self.label_hsi)

def gain_neighborhood_pixel(mirror_image, point, i, patch=5):
    x = point[i, 0]
    y = point[i, 1]
    temp_image = mirror_image[x:(x + patch), y:(y + patch), :]
    return temp_image

def train_and_test_data(mirror_image, band, train_point, test_point, patch=5):
    x_train = np.zeros((train_point.shape[0], patch, patch, band), dtype=np.float32)
    x_test = np.zeros((test_point.shape[0], patch, patch, band), dtype=np.float32)

    for i in range(train_point.shape[0]):
        x_train[i, :, :, :] = gain_neighborhood_pixel(mirror_image, train_point, i, patch)
    for j in range(test_point.shape[0]):
        x_test[j, :, :, :] = gain_neighborhood_pixel(mirror_image, test_point, j, patch)

    print("x_train shape = {}, type = {}".format(x_train.shape, x_train.dtype))
    print("x_test  shape = {}, type = {}".format(x_test.shape, x_test.dtype))
    return x_train, x_test

def generate_iter(label_train, train_indices, y_test, test_indices, VAL_SIZE,
                  PATCH_LENGTH, padded_data_hsi, padded_data_dmi, INPUT_DIMENSION_HSI, INPUT_DIMENSION_DSM, batch_size, noise_type, noise_ratio,noise_ratio2):
    x_train_hsi, x_test_all_hsi = train_and_test_data(padded_data_hsi, INPUT_DIMENSION_HSI, train_indices, test_indices,
                                                      patch=PATCH_LENGTH)
    x_train_dmi, x_test_all_dmi = train_and_test_data(padded_data_dmi, INPUT_DIMENSION_DSM, train_indices, test_indices,
                                                      patch=PATCH_LENGTH)
    y_test = np.array(y_test)
    y_traingt = np.array(label_train)
    y_train_hsi = get_noisy_label(label_train, percent=noise_ratio, noise_type=noise_type)
    print(y_train_hsi)
    print("----------------------------------------")
    y_train_dmi = get_noisy_label(label_train, percent=noise_ratio2, noise_type=noise_type)
    print(y_train_dmi)
    indices = np.random.permutation(len(y_test))

    x_test_hsi = x_test_all_hsi[indices][:-VAL_SIZE]
    x_test_dmi = x_test_all_dmi[indices][:-VAL_SIZE]
    y_test = y_test[indices][:-VAL_SIZE]

    noise_rate = np.subtract(np.array(y_train_hsi), np.array(label_train))
    noise_ratio = len(noise_rate[np.nonzero(noise_rate)]) / float(len(y_train_hsi))
    print('True_noise_ratio1:', noise_ratio)
    noise_rate2 = np.subtract(np.array(y_train_dmi), np.array(label_train))
    noise_ratio2 = len(noise_rate2[np.nonzero(noise_rate2)]) / float(len(y_train_dmi))
    print('True_noise_ratio1:', noise_ratio2)

    torch_dataset_train = HSIDA(images=(x_train_hsi, x_train_dmi),
                                labels=(torch.from_numpy(y_train_hsi).type(torch.LongTensor),
                                        torch.from_numpy(y_train_dmi).type(torch.LongTensor)),
                                labels_gt=torch.from_numpy(y_traingt).type(torch.LongTensor), mode='train')


    torch_dataset_test = HSIDA(images=(x_test_hsi, x_test_dmi), labels=(torch.from_numpy(y_test).type(torch.LongTensor),
                                                                        torch.from_numpy(y_test).type(torch.LongTensor)),
                               labels_gt=torch.from_numpy(y_test).type(torch.LongTensor), mode='test')

    train_iter = Data.DataLoader(
        dataset=torch_dataset_train,
        batch_size=batch_size,
        shuffle=True,
        num_workers=0,
    )
    test_iter = Data.DataLoader(
        dataset=torch_dataset_test,
        batch_size=batch_size,
        shuffle=False,
        num_workers=0,
    )
    return train_iter, test_iter

def get_noisy_label(tru_label, percent, noise_type='sym'):
    tru_label = np.asarray(tru_label)
    y_train = np.array(tru_label)
    start = int(min(tru_label))
    end = int(max(tru_label))
    if noise_type == 'sym':
        if percent < 1:
            indices = np.random.permutation(len(y_train))
            for i, idx in enumerate(indices):
                if i < percent * len(y_train):
                    temp_list = np.arange(start, end + 1).tolist()
                    temp_list.remove(y_train[idx])
                    y_train[idx] = np.random.choice(temp_list)

        elif percent > 1:
            for i in range(start, end + 1):
                ttemp = np.where(tru_label == i)
                temp_list = np.arange(start, end + 1).tolist()
                temp_list.remove(i)
                number = len(y_train[ttemp])
                temp = np.random.choice(temp_list, size=number)
                temp[percent:] = i
                np.random.shuffle(temp)
                y_train[ttemp] = temp

    elif noise_type == 'asym':
        indices = np.random.permutation(len(y_train))
        if percent < 1:
            for i, idx in enumerate(indices):
                if i < percent * len(y_train):
                    y_train[idx] = (y_train[idx] + 1) % (max(tru_label) + 1) + min(tru_label)
        elif percent > 1:
            for i in range(start, end + 1):
                ttemp = np.where(tru_label == i)
                temp_value = (i + 1) % (end + 1) + start
                number = len(y_train[ttemp])
                temp = np.ones(number) * temp_value
                temp[percent:] = i
                np.random.shuffle(temp)
                y_train[ttemp] = temp
    return y_train

def generate_all(true_point, patch, mirror_image_hsi, mirror_image_dmi, band_hsi, band_dmi, batch_size=128):
    gt_all = np.zeros(true_point.shape[0])

    all_data_hsi = np.zeros((true_point.shape[0], patch, patch, band_hsi), dtype=np.float32)
    all_data_dmi = np.zeros((true_point.shape[0], patch, patch, band_dmi), dtype=np.float32)
    for k in range(true_point.shape[0]):
        all_data_hsi[k, :, :, :] = gain_neighborhood_pixel(mirror_image_hsi, true_point, k, patch)
        all_data_dmi[k, :, :, :] = gain_neighborhood_pixel(mirror_image_dmi, true_point, k, patch)

    print("All data HSI: shape = {}, type = {}".format(all_data_hsi.shape, all_data_hsi.dtype))
    print("All data DSM: shape = {}, type = {}".format(all_data_dmi.shape, all_data_dmi.dtype))
    torch_dataset_all = HSIDA(images=(all_data_hsi, all_data_dmi), labels=(torch.from_numpy(gt_all).type(torch.LongTensor),
                                                                           torch.from_numpy(gt_all).type(torch.LongTensor)),
                              labels_gt=torch.from_numpy(gt_all).type(torch.LongTensor), mode='test')

    all_iter = Data.DataLoader(
        dataset=torch_dataset_all,
        batch_size=batch_size,
        shuffle=False,
        num_workers=0,
    )
    return all_iter

def load_dataset(Dataset):
    if Dataset == 'Houston2013':
        Houston2013_hsi = sio.loadmat('F:\maple\multidata\HS-DSM_Houston2013/Houston2013_HSI.mat')
        data_hsi = Houston2013_hsi['HSI']
        Houston2013_dsm = sio.loadmat('F:\maple\multidata\HS-DSM_Houston2013/Houston2013_DSM.mat')
        data_dmi = Houston2013_dsm['DSM']

        if data_dmi.ndim == 2:
            data_dmi = data_dmi[:, :, np.newaxis]

        gt_Houston2013 = sio.loadmat('F:\maple\multidata\HS-DSM_Houston2013\houston2013_gt.mat')
        gt = gt_Houston2013['houston2013_gt']
        TOTAL_SIZE = data_hsi.shape[0] * data_hsi.shape[1]
    if Dataset == 'Berlin':
        Houston2013_hsi = sio.loadmat('F:\maple\multidata\HS-SAR_Berlin/data_HS_LR_PCA60.mat')
        data_hsi = Houston2013_hsi['data_HS_LR_PCA']
        Houston2013_dsm = sio.loadmat('F:\maple\multidata\HS-SAR_Berlin/data_SAR_HR.mat')
        data_dmi = Houston2013_dsm['data_SAR_HR']

        if data_dmi.ndim == 2:
            data_dmi = data_dmi[:, :, np.newaxis]

        gt_Houston2013 = sio.loadmat('F:\maple\multidata\HS-SAR_Berlin/berlin_gt.mat')
        gt = gt_Houston2013['berlin_gt']
        TOTAL_SIZE = data_hsi.shape[0] * data_hsi.shape[1]

    if Dataset == 'Augsburg':
        Houston2013_hsi = sio.loadmat('F:\maple\multidata\HS-SAR-DSM_Augsburg/data_HS_LR.mat')
        data_hsi = Houston2013_hsi['data_HS_LR']
        Houston2013_dsm = sio.loadmat('F:\maple\multidata\HS-SAR-DSM_Augsburg/data_SAR_HR.mat')
        data_dmi = Houston2013_dsm['data_SAR_HR']

        if data_dmi.ndim == 2:
            data_dmi = data_dmi[:, :, np.newaxis]

        gt_Houston2013 = sio.loadmat('F:\maple\multidata\HS-SAR-DSM_Augsburg/augsburg_gt_int.mat')
        gt = gt_Houston2013['augsburg_gt']
        TOTAL_SIZE = data_hsi.shape[0] * data_hsi.shape[1]

    return data_hsi, data_dmi, gt, TOTAL_SIZE

def sampling(proportion, ground_truth, num_class):
    train = {}
    test = {}
    train_gt = []
    test_gt = []
    for i in range(num_class):
        each_class = np.argwhere(ground_truth == i + 1)
        number = each_class.shape[0]
        tmp = np.ones(number) * i
        np.random.shuffle(each_class)
        if proportion < 1:
            nb_tra = int(np.ceil(proportion * number))
        if proportion > 1:
            nb_tra = proportion
            if proportion > number:
                nb_tra = 15
        train[i] = each_class[:nb_tra, :]
        test[i] = each_class[nb_tra:, :]
        train_gt += tmp[:nb_tra].tolist()
        test_gt += tmp[nb_tra:].tolist()

    train_pos = train[0]
    for i in range(1, num_class):
        train_pos = np.r_[train_pos, train[i]]
    train_pos = train_pos.astype(int)

    test_pos = test[0]
    for i in range(1, num_class):
        test_pos = np.r_[test_pos, test[i]]
    test_pos = test_pos.astype(int)

    print("The num of labeled data for noisy training:", train_pos.shape[0])
    print("The num of labeled data for test and validation:", test_pos.shape[0])
    print("The total num of labeled data ", train_pos.shape[0] + test_pos.shape[0])

    return train_pos, train_gt, test_pos, test_gt

def get_all_index(true_data, num_classes):
    total_pos = []
    for i in range(true_data.shape[0]):
        for j in range(true_data.shape[1]):
            total_pos.append([i, j])
    total_pos = np.array(total_pos)

    print("The num of all data for drawing the full classification map:", len(total_pos))

    return total_pos

def aa_and_each_accuracy(confusion_matrix):
    list_diag = np.diag(confusion_matrix)
    list_raw_sum = np.sum(confusion_matrix, axis=1)
    each_acc = np.nan_to_num(truediv(list_diag, list_raw_sum))
    average_acc = np.mean(each_acc)
    return each_acc, average_acc



# def test_data_processing():
#     # 设置参数
#     Dataset = 'Houston2013'
#     batch_size = 64
#     PATCH_LENGTH = 5
#     flag = 'train'
#     Train_size = 76
#     noise_type = 'sym'
#     noise_ratio = 24
#
#     # 调用数据处理函数
#     train_iter,  test_iter, train_indices = data_processing(
#         Dataset=Dataset,
#         batch_size=batch_size,
#         PATCH_LENGTH=PATCH_LENGTH,
#         flag=flag,
#         Train_size=Train_size,
#         noise_type=noise_type,
#         noise_ratio=noise_ratio
#     )
#
#     # 打印一些信息以验证数据加载是否正确
#     print("Number of training batches:", len(train_iter))
#     print("Number of test batches:", len(test_iter))
#
#     # 取一个batch进行测试
#     for batch in train_iter:
#         hsi_images, dmi_images, hsi_label, dmi_label, _ = batch
#         print("HSI batch shape:", hsi_images.shape)
#         print("DSM batch shape:", dmi_images.shape)
#         print("hsi_label batch shape:", hsi_label.shape)
#         print("dmi_label batch shape:", dmi_label.shape)
#         print(hsi_label)
#         print("-------------------------------------------")
#         print(dmi_label)
#         if(np.array_equal(hsi_label, dmi_label)):
#             print("yiyangle")
#         break
#
# if __name__ == "__main__":
#     test_data_processing()
