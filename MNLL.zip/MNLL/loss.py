import torch
import torch.nn.functional as F
import loss_conbine

class ContrastiveLoss(torch.nn.Module):
    def __init__(self, temperature=0.25):
        super(ContrastiveLoss, self).__init__()
        self.temperature = temperature

    def forward(self, features1, features2):
        # Normalize features
        features1 = F.normalize(features1, dim=1)
        features2 = F.normalize(features2, dim=1)

        # Compute similarity matrix
        similarity_matrix = torch.matmul(features1, features2.T) / self.temperature

        # Create labels for positive pairs
        labels = torch.arange(features1.size(0)).to(features1.device)

        # Compute InfoNCE loss
        loss = F.cross_entropy(similarity_matrix, labels)
        return loss

class ConsistencyLoss(torch.nn.Module):
    def __init__(self):
        super(ConsistencyLoss, self).__init__()

    def forward(self, output1, output2):
        output1 = torch.sigmoid(output1)
        output2 = torch.sigmoid(output2)

        output1 = torch.clamp(output1, min=1e-7, max=1 - 1e-7)
        output2 = torch.clamp(output2, min=1e-7, max=1 - 1e-7)

        return F.binary_cross_entropy(output1, output2)


class ClassificationLoss(torch.nn.Module):
    def __init__(self):
        super(ClassificationLoss, self).__init__()
        self.criterion = torch.nn.CrossEntropyLoss()

    def forward(self, outputs, labels):
        return self.criterion(outputs, labels)

def co_loss(hsi_cl, dsm_cl, label_hsi, label_dsm, joint_cl, prob_hsi, prob_dsm,
            threshold_hsi, threshold_dsm, batch_index,hsi1_proj,hsi2_proj,dsm1_proj,dsm2_proj):
    if isinstance(batch_index, torch.Tensor):
        batch_index = batch_index.cpu().numpy()
    zero_loss = 0.0 * joint_cl.sum()
    batch_prob_hsi = prob_hsi[batch_index]
    batch_prob_dsm = prob_dsm[batch_index]

    # --- dataset num_classes ---
    GCEandNCE = loss_conbine.GCEandNCE(num_classes=15)
    # --- 按类别选threshold ---
    threshold_hsi_per_sample = threshold_hsi[label_hsi].cpu().numpy()
    threshold_dsm_per_sample = threshold_dsm[label_dsm].cpu().numpy()


    # Case 1: 两个模态置信度都高
    high_confidence = (batch_prob_hsi > threshold_hsi_per_sample) & (batch_prob_dsm > threshold_dsm_per_sample)

    if high_confidence.any():
        idx = torch.tensor(high_confidence).to(joint_cl.device)

        label_hsi_sel = label_hsi[idx]
        label_dsm_sel = label_dsm[idx]
        joint_sel = joint_cl[idx]

        prob_hsi_sel = torch.tensor(batch_prob_hsi[high_confidence]).to(joint_cl.device)
        prob_dsm_sel = torch.tensor(batch_prob_dsm[high_confidence]).to(joint_cl.device)

        agreement_mask = (label_hsi_sel == label_dsm_sel)
        disagreement_mask = (label_hsi_sel != label_dsm_sel)

        loss_agree = torch.tensor(0.0, device=joint_cl.device)
        loss_disagree = torch.tensor(0.0, device=joint_cl.device)

        if agreement_mask.any():
            idx_agree = torch.where(agreement_mask)[0]
            loss_agree = F.cross_entropy(joint_sel[idx_agree], label_hsi_sel[idx_agree])

        if disagreement_mask.any():
            idx_disagree = torch.where(disagreement_mask)[0]

            y_hsi = label_hsi_sel[idx_disagree]
            y_dsm = label_dsm_sel[idx_disagree]
            joint_logits = joint_sel[idx_disagree]
            p_hsi = prob_hsi_sel[idx_disagree]
            p_dsm = prob_dsm_sel[idx_disagree]
            p_sum = p_hsi + p_dsm + 1e-8

            # 加权交叉熵损失
            w_hsi = p_hsi / p_sum
            w_dsm = p_dsm / p_sum

            ce_hsi = F.cross_entropy(joint_logits, y_hsi, reduction='none')
            ce_dsm = F.cross_entropy(joint_logits, y_dsm, reduction='none')

            loss_disagree = torch.mean(w_hsi * ce_hsi + w_dsm * ce_dsm)

        loss_case1 = loss_agree + loss_disagree
    else:
        loss_case1 = zero_loss

    # Case 2: 只有HSI置信度高
    hsi_high_confidence = (batch_prob_hsi > threshold_hsi_per_sample) & (batch_prob_dsm <= threshold_dsm_per_sample)
    if hsi_high_confidence.any():
        loss_case2 = GCEandNCE(dsm_cl[hsi_high_confidence], label_hsi[hsi_high_confidence])
    else:
        loss_case2 = zero_loss

    # Case 3: 只有DSM置信度高
    dsm_high_confidence = (batch_prob_dsm > threshold_dsm_per_sample) & (batch_prob_hsi <= threshold_hsi_per_sample)
    if dsm_high_confidence.any():
        loss_case3 = GCEandNCE(hsi_cl[dsm_high_confidence], label_dsm[dsm_high_confidence])
    else:
        loss_case3 = zero_loss

    # # Case 4: 两个模态置信度都低
    low_confidence = (batch_prob_hsi <= threshold_hsi_per_sample) & (batch_prob_dsm <= threshold_dsm_per_sample)
    if low_confidence.any():
        simclr_loss_fn = loss_conbine.NTXentLoss(hsi1_proj.device, temperature=0.25, use_cosine_similarity=True)
        low_idx = torch.tensor(low_confidence).to(hsi1_proj.device)
        hsi_loss = simclr_loss_fn(hsi1_proj[low_idx], hsi2_proj[low_idx])
        dsm_loss = simclr_loss_fn(dsm1_proj[low_idx], dsm2_proj[low_idx])
        loss_case4 = hsi_loss + dsm_loss
    else:
        loss_case4 = zero_loss

    total_loss = loss_case1+ 0.5 * (loss_case2 + loss_case3) + 0.5*loss_case4

    return total_loss
