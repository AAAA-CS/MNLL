algorithm = 'MNLL'
# dataset param
dataset = 'Houston2013'  #Houston2013 144 15(network dim->1)  Berlin 244 8(network dim->4) Augsburg 180 7(network dim->4)
input_channel = 144   # channel of data
num_classes = 15   # number of class
train_size = 100  # Total number of samples in each class
patch_length = 9

noise_type = 'sym'  # 'sym' or 'asym'
percent = 30  # the number of noisy samples per class
percent2 = 30
warmup = 20

# model param
feature_dim = 64
# train param
batch_size = 64   # batch size
num_workers = 1
lr = 0.0006    # learning rate
epochs = 30  # epoch
adjust_lr = 1
epoch_decay_start = 80
save_result = True

