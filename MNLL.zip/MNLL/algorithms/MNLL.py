import torch
import numpy as np
import torch.nn.functional as F
from sklearn.mixture import GaussianMixture
from torch import nn

import network
from tqdm import tqdm
from loss import ContrastiveLoss, ClassificationLoss, ConsistencyLoss, co_loss
from utils.tools import convert_to_cuda
device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')


class MNLL:
    def __init__(
            self,
            config: dict = None,
            input_channel: int = 103,
            num_classes: int = 9,
    ):

        self.batch_size = config['batch_size']
        self.lr = config['lr']

        # Adjust learning rate and betas for Adam Optimizer
        mom1 = 0.9
        mom2 = 0.1
        self.alpha_plan = [self.lr] * config['epochs']
        self.beta1_plan = [mom1] * config['epochs']

        for i in range(config['epoch_decay_start'], config['epochs']):
            self.alpha_plan[i] = float(config['epochs'] - i) / (
                        config['epochs'] - config['epoch_decay_start']) * self.lr
            self.beta1_plan[i] = mom2

        self.device = device
        self.epochs = config['epochs']

        self.model_scratch = network.mynet(input_channel, num_classes).to(self.device)
        self.optimizer = torch.optim.Adam(self.model_scratch.parameters(), lr=self.lr)

        self.adjust_lr = config['adjust_lr']



    def evaluate(self, test_loader):
        print('Evaluating ...')
        self.model_scratch.eval()  # Change model to 'eval' mode
        gt_test = []
        pre = []
        correct2 = 0
        total2 = 0
        for inputs in test_loader:
            image_hsi, image_dsm, labels,_, index = convert_to_cuda(inputs)
            _, _, _, _, logits2 = self.model_scratch(image_hsi, image_dsm)
            outputs2 = F.softmax(logits2, dim=1)
            _, pred2 = torch.max(outputs2.data, 1)
            total2 += labels.size(0)
            correct2 += (pred2 == labels).sum()
            gt_test.extend(np.array(labels.cpu()))
            pre.extend(np.array(pred2.cpu()))

        acc = 100 * float(correct2) / float(total2)
        return acc, pre, gt_test
        


    def eval_train(self, train_loader):
        CE = nn.CrossEntropyLoss(reduction='none')
        self.model_scratch.eval()
        losses_hsi = torch.zeros(len(train_loader.dataset))
        losses_dsm = torch.zeros(len(train_loader.dataset))
        labels_hsi = torch.zeros(len(train_loader.dataset), dtype=torch.long)
        labels_dsm = torch.zeros(len(train_loader.dataset), dtype=torch.long)

        with torch.no_grad():
            for inputs in train_loader:
                image_hsi, image_dsm, label_hsi, label_dsm, index,_,_,_,_ = convert_to_cuda(inputs)
                _, hsi_cl, _, dsm_cl, joint_cl = self.model_scratch(image_hsi, image_dsm)

                loss_hsi = CE(hsi_cl, label_hsi)
                loss_dsm = CE(dsm_cl, label_dsm)

                for b in range(image_hsi.size(0)):
                    losses_hsi[index[b]] = loss_hsi[b]
                    labels_hsi[index[b]] = label_hsi[b]
                for b in range(image_dsm.size(0)):
                    losses_dsm[index[b]] = loss_dsm[b]
                    labels_dsm[index[b]] = label_dsm[b]

        # 归一化
        losses_hsi = (losses_hsi - losses_hsi.min()) / (losses_hsi.max() - losses_hsi.min())
        losses_dsm = (losses_dsm - losses_dsm.min()) / (losses_dsm.max() - losses_dsm.min())

        input_loss_hsi = losses_hsi.reshape(-1, 1)
        input_loss_dsm = losses_dsm.reshape(-1, 1)

        # GMM拟合

        gmm_hsi = GaussianMixture(n_components=2, max_iter=200, tol=1e-2, reg_covar=5e-4)
        gmm_hsi.fit(input_loss_hsi)
        prob_hsi = gmm_hsi.predict_proba(input_loss_hsi)
        prob_hsi = prob_hsi[:, gmm_hsi.means_.argmin()]


        gmm_dsm = GaussianMixture(n_components=2, max_iter=200, tol=1e-2, reg_covar=5e-4)
        gmm_dsm.fit(input_loss_dsm)
        prob_dsm = gmm_dsm.predict_proba(input_loss_dsm)
        prob_dsm = prob_dsm[:, gmm_dsm.means_.argmin()]

        # --- 这里开始按每一类计算阈值 ---
        num_classes = labels_hsi.max().item() + 1  # 类别数（假设类别从0开始连续编号）
        threshold_hsi = torch.zeros(num_classes)
        threshold_dsm = torch.zeros(num_classes)

        for c in range(num_classes):
            class_mask_hsi = (labels_hsi == c)
            class_mask_dsm = (labels_dsm == c)

            if class_mask_hsi.sum() > 0:
                prob_hsi_c = prob_hsi[class_mask_hsi]
                threshold_hsi[c] = prob_hsi_c.mean() + 0.2*prob_hsi_c.std()
            else:
                threshold_hsi[c] = 1.0  # 如果某类没样本，就设置最大置信度

            if class_mask_dsm.sum() > 0:
                prob_dsm_c = prob_dsm[class_mask_dsm]
                threshold_dsm[c] = prob_dsm_c.mean() + 0.2*prob_dsm_c.std()
            else:
                threshold_dsm[c] = 1.0

        print(threshold_hsi)
        print(threshold_dsm)

        return prob_hsi, prob_dsm, threshold_hsi, threshold_dsm

    def warmuptrain(self, train_loader, epoch):
        print('warmup ...')
        self.model_scratch.train()

        if self.adjust_lr:
            self.adjust_learning_rate(self.optimizer, epoch)

        correct0 = 0
        correct1 = 0
        total = 0
        pbar = tqdm(train_loader)
        for item in pbar:
            image_hsi, image_dsm, label_hsi, label_dsm, index,_,_,_,_ = convert_to_cuda(item)
            hsi_projection, hsi_cl, dsm_projection, dsm_cl, joint_cl = self.model_scratch(image_hsi, image_dsm)
            contrastive_loss_fn = ContrastiveLoss()
            classification_loss_fn = ClassificationLoss()

            loss_contrastive = contrastive_loss_fn(hsi_projection, dsm_projection)
            loss_classification = (classification_loss_fn(hsi_cl, label_hsi)+classification_loss_fn(dsm_cl, label_dsm))
            total_loss = loss_contrastive + loss_classification
            self.optimizer.zero_grad()
            total_loss.backward()
            self.optimizer.step()

            outputs = F.softmax(joint_cl, dim=1)
            _, pred = torch.max(outputs.data, 1)
            total += label_hsi.size(0)
            correct0 += (pred == label_hsi).sum()
            correct1 += (pred == label_dsm).sum()
            correct = (correct0+correct1)/2
            acc = float(correct) / float(total)

            pbar.set_description(
                'Epoch [%d/%d], loss_con: %.4f, train_acc: %.4f'
                % (epoch + 1, self.epochs, total_loss.data.item(),  acc))

        acc_train = 100 * float(correct) / float(total)
        return acc_train



    def train(self, train_loader, epoch):
        print('Training ...')

        prob_hsi,prob_dsm,threshold_hsi, threshold_dsm = self.eval_train(train_loader)
        self.model_scratch.train()

        if self.adjust_lr:
            self.adjust_learning_rate(self.optimizer, epoch)

        # threshold = 0.5

        correct0 = 0
        correct1 = 0
        total = 0
        pbar = tqdm(train_loader)
        for item in pbar:
            image_hsi, image_dsm, label_hsi, label_dsm, index,img1_hsi,img2_hsi,img1_dsm,img2_dsm = convert_to_cuda(item)

            hsi_projection, hsi_cl, dsm_projection, dsm_cl, joint_cl = self.model_scratch(image_hsi, image_dsm)
            hsi1_proj, _, dsm1_proj, _, _ = self.model_scratch(img1_hsi, img1_dsm)
            hsi2_proj, _, dsm2_proj, _, _ = self.model_scratch(img2_hsi, img2_dsm)
            contrastive_loss_fn = ContrastiveLoss()
            consistency_loss_fn = ConsistencyLoss()

            loss_contrastive = contrastive_loss_fn(hsi_projection, dsm_projection)
            loss_consistency = 1/2*(consistency_loss_fn(hsi_cl, joint_cl) + consistency_loss_fn(dsm_cl, joint_cl))

            loss_classification = co_loss(hsi_cl, dsm_cl, label_hsi, label_dsm, joint_cl, prob_hsi, prob_dsm,
                        threshold_hsi, threshold_dsm, index, img1_hsi, img2_hsi, img1_dsm, img2_dsm)

            # Total loss
            total_loss = loss_contrastive + loss_consistency + loss_classification
            # Backpropagation
            self.optimizer.zero_grad()
            total_loss.backward()
            self.optimizer.step()

            outputs = F.softmax(joint_cl, dim=1)
            _, pred = torch.max(outputs.data, 1)
            total += label_hsi.size(0)
            correct0 += (pred == label_hsi).sum()
            correct1 += (pred == label_dsm).sum()
            correct = (correct0+correct1)/2
            acc = float(correct) / float(total)

            pbar.set_description(
                'Epoch [%d/%d], loss_con: %.4f, train_acc: %.4f'
                % (epoch + 1, self.epochs, total_loss.data.item(),  acc))

        acc_train = 100 * float(correct) / float(total)
        return acc_train

    def adjust_learning_rate(self, optimizer, epoch):
        for param_group in optimizer.param_groups:
            param_group['lr'] = self.alpha_plan[epoch]
            #param_group['betas'] = (self.beta1_plan[epoch], 0.999)  # Only change beta1
